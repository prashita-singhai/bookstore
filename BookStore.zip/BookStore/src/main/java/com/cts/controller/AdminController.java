package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bean.Admin;
import com.cts.bean.DetailsBooks;
import com.cts.service.AdminService;

@Controller
public class AdminController {

	@Autowired
	public AdminService adminservice;
	
	@RequestMapping(value="registerAdmin", method=RequestMethod.GET)
	public ModelAndView  registeradmin(@ModelAttribute Admin admin) {
		ModelAndView mv= new ModelAndView();
		adminservice.registeradmin(admin);
		mv.setViewName("AdminLogin");
		return mv;
	}
	@RequestMapping(value="adminLogin", method=RequestMethod.POST)
	public ModelAndView loginAdmin(@RequestParam("username") String username,@RequestParam("password")String password) {
		ModelAndView mv= new ModelAndView();
		boolean result=adminservice.loginAdmin(username,password);
		if(result==true) {
			System.out.println("hi");
			mv.setViewName("BooksDetails");
		}
		
		return mv;
	}
	
	@RequestMapping(value="bookDetails",method=RequestMethod.GET)
	public ModelAndView addBook(@ModelAttribute DetailsBooks bookdetails) {
		ModelAndView mv= new ModelAndView();
		System.out.println("in con 0");
		
		boolean result=adminservice.addBook(bookdetails);
		System.out.println("in con 1");
		
		if(result==true) {		
			
		System.out.println("in con");
			mv.addObject("status" ,"added Successfully");
		mv.setViewName("BooksDetails");
		
		}
		return mv;
	}
}
