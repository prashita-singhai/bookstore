package com.cts.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {
	
	
	@RequestMapping("/")
	public String welcomepage(){
		return "Welcome";
	}
	
	@RequestMapping("adminRegister")
	public String adminregister() {
		return "AdminRegister";
	}
	@RequestMapping("adminlogin")
	public String adminlogin() {
		return "AdminLogin";
	}
	@RequestMapping("customerRegister")
	public String customerregister() {
		return "CustomerRegister";
	}
	@RequestMapping("customerlogin")
	public String Customerlogin() {
		return "CustomerLogin";
	}

}
