package com.cts.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bean.Admin;
import com.cts.bean.Cart;
import com.cts.bean.DetailsBooks;
import com.cts.bean.User;
import com.cts.service.CustomerService;
@Controller
public class CustomerController {

	
	@Autowired
	public CustomerService customerservice;
	
	@RequestMapping(value="registerCustomer", method=RequestMethod.GET)
	public ModelAndView  registeradmin(@ModelAttribute User user) {
		ModelAndView mv= new ModelAndView();
		System.out.println("in ctrl");
		customerservice.customerRegister(user);
		System.out.println("in cgtrl2");
		mv.setViewName("CustomerLogin");
		return mv;
	}
	@RequestMapping(value="customerLogin", method=RequestMethod.POST)
	public ModelAndView loginCustomer(@RequestParam("username") String username,@RequestParam("password")String password,HttpServletRequest request) {
		ModelAndView mv= new ModelAndView();
		User myself=customerservice.customerLogin(username, password);
		int myId=myself.getId();
		HttpSession session=request.getSession(); // so we can use it anywhere
		session.setAttribute("Uid",myId);
		if(myself!=null) {
			System.out.println("hi");
			List<DetailsBooks> bookList= customerservice.getBooks();
			mv.addObject("allbooks",bookList);
			mv.setViewName("CustomerWelcome");
		}
		
		return mv;
	}
	@RequestMapping(value="add")
	public ModelAndView AddtoCart(@RequestParam("id") int id,HttpServletRequest request) {
		ModelAndView mv= new ModelAndView();
		DetailsBooks bookD= customerservice.getBookDetails(id);
		HttpSession session=request.getSession();
		int userId=(Integer)request.getSession().getAttribute("Uid");
		System.out.println("hi lion "+userId);
		User user=customerservice.getCustomerDetails(userId);
		Cart myitem= new Cart();
		myitem.setUserId(userId); // to create row
		myitem.setuName(user.getUsername());
		myitem.setbName(bookD.getBookName());
		myitem.setPrice(bookD.getBookPrice());
		myitem.setBookId(bookD.getId());
		boolean result=customerservice.AddtoCart(myitem); // to add to table
		if(result==true) {
			System.out.println("hi");
			List<DetailsBooks> bookList= customerservice.getBooks();
			mv.addObject("allbooks",bookList);
			mv.setViewName("CustomerWelcome");
		}		
		return mv;
	}
	@RequestMapping(value="showCart")
	public ModelAndView showcart(HttpServletRequest request) {
		ModelAndView mv= new ModelAndView();
		int userId=(Integer)request.getSession().getAttribute("Uid"); // to retrieve items to cart
		List<Cart> mycart=customerservice.getmyitems(userId);
		mv.addObject("item",mycart);
		mv.setViewName("MyCart");
		return mv;
	}
	
}
