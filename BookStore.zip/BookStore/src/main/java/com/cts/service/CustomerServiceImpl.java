package com.cts.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.bean.Cart;
import com.cts.bean.DetailsBooks;
import com.cts.bean.User;
import com.cts.dao.CustomerDAO;


@Service("CustomerService")
public class CustomerServiceImpl implements CustomerService {

	@Autowired
    public CustomerDAO customerdao;
	
	public boolean customerRegister(User user) {
	System.out.println("in service");
		return customerdao.customerRegister(user);
	}

	public User customerLogin(String username, String password) {

		return customerdao.customerLogin(username, password);
	}

	public List<DetailsBooks> getBooks() {
		
		return customerdao.getBooks();
	}

	public DetailsBooks getBookDetails(int id) {
		
		return customerdao.getBookDetails(id);
	}

	public User getCustomerDetails(int id) {

		return customerdao.getCustomerDetails(id);
	}

	public boolean AddtoCart(Cart myitem) {
	
		return customerdao.AddtoCart(myitem);
	}

	public List<Cart> getmyitems(int userId) {
		return customerdao.getmyitems(userId);
	}

	
}
