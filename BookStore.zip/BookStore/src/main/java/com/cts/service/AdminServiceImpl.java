package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.bean.Admin;
import com.cts.bean.DetailsBooks;
import com.cts.dao.Admindao;

@Service("AdminService")
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	public Admindao admindao;
	
	public boolean registeradmin(Admin admin) {
		 return admindao.registeradmin(admin);
	}

	public boolean loginAdmin(String username, String password) {
		// TODO Auto-generated method stub
		return admindao.loginAdmin(username, password);
	}
	public boolean addBook(DetailsBooks bookdetails) {
		return admindao.addBook(bookdetails);
	}



}
