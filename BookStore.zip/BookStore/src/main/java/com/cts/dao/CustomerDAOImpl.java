package com.cts.dao;

import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cts.bean.Admin;
import com.cts.bean.Cart;
import com.cts.bean.DetailsBooks;
import com.cts.bean.User;

@Repository("CustomerDAO")
public class CustomerDAOImpl implements CustomerDAO{

	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	
	@Transactional
	public boolean customerRegister(User user) {
		Session session=sessionFactory.getCurrentSession();
		System.out.println("in dao");
		session.save(user);		
		return true ;
	}
	
	@Transactional
	public User customerLogin(String username, String password) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from User where username=? and password=?");
		query.setParameter(0,username);
		query.setParameter(1,password);
		User user=(User)query.getSingleResult();
		return user ;
		
	}
	@Transactional
	public List<DetailsBooks> getBooks() {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from DetailsBooks");
		List<DetailsBooks> bookList=query.getResultList();
		return bookList;
	}

	@Transactional
	public DetailsBooks getBookDetails(int id) {
			Session session=sessionFactory.getCurrentSession();
			Query query=session.createQuery("from DetailsBooks where id=?");
			query.setParameter(0, id);
			DetailsBooks bookDetail=(DetailsBooks)query.getSingleResult();
			return bookDetail;
		
	}
@Transactional
	public User getCustomerDetails(int id) {
		Session session=sessionFactory.getCurrentSession();
		Query query =session.createQuery("from User where id=?");
		query.setParameter(0, id);
		User user=(User)query.getSingleResult();
		System.out.println(user.getUsername());
		return user;
	}
@Transactional
public boolean AddtoCart(Cart myitem) {
	Session session=sessionFactory.getCurrentSession();
	session.save(myitem);
	return true;
}
@Transactional
public List<Cart> getmyitems(int userId) {
	Session session=sessionFactory.getCurrentSession();
	Query query =session.createQuery("from Cart where userId=?");
	query.setParameter(0, userId);
	List<Cart> myitems=query.getResultList();
	return myitems;
}
}
