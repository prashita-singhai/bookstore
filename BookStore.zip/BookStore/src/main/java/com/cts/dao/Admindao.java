package com.cts.dao;



import com.cts.bean.Admin;
import com.cts.bean.DetailsBooks;


public interface Admindao {
	
	
	public boolean registeradmin(Admin admin);
	public boolean loginAdmin(String username,String password);
	public boolean addBook(DetailsBooks bookdetails);
	

}
