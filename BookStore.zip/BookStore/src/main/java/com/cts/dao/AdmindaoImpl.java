package com.cts.dao;


import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cts.bean.Admin;
import com.cts.bean.DetailsBooks;

@Repository("Admindao")
public class AdmindaoImpl implements Admindao{
	
	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	
	@Transactional
	public boolean registeradmin(Admin admin) {
		Session session=sessionFactory.getCurrentSession();
		session.save(admin);
		
		return true ;
	}
	@Transactional
	public boolean loginAdmin(String username, String password) {
		
		Session session=null;
		session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Admin where username=? and password=?");
		query.setParameter(0,username);
		query.setParameter(1,password);
		query.getSingleResult();
		return true ;
	}
	@Transactional
	public boolean addBook(DetailsBooks bookdetails) {
		Session session=sessionFactory.getCurrentSession();
		System.out.println("in dao");
		
		System.out.println(bookdetails.getBookName());
		System.out.println(bookdetails.getBookDesc());
		System.out.println(bookdetails.getBookPrice());
		System.out.println(bookdetails.getBookAuthor());
		
		session.save(bookdetails);
		System.out.println("in dao 2");
		return true ;
	}
	

}
