package com.cts.dao;

import java.util.List;

import com.cts.bean.Cart;
import com.cts.bean.DetailsBooks;
import com.cts.bean.User;

public interface CustomerDAO {

	public boolean customerRegister(User user);
	public User customerLogin(String username,String password);
	public List<DetailsBooks> getBooks();
	public DetailsBooks getBookDetails(int id);
	public User getCustomerDetails(int id);
	public boolean AddtoCart(Cart myitem);
	public List<Cart> getmyitems(int userId);
}
